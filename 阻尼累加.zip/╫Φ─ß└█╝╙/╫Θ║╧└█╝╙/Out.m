clear;clc
warning off
fobj=@DAGM;
X0=Input;
[Leader_score,Leader_pos,Convergence_curve]=WOA(50,300,0,1,2,fobj,X0);
[MAPE,X0F]=DAGM(Leader_pos,X0);
[MAPE,X0F]=DAGM([0.04612,1],X0)