[MAPE,X0F]=NIPEGM(0.1,X0,3);FF=X0F';
for i=0.2:0.1:1
[MAPE,X0F]=NIPEGM(i,X0,3);X0F=X0F';FF=[FF X0F];
end

clear;clc
[MAPE,FF]=fitness1(0.1);
for i=0.2:0.1:1
	[MAPE,X0F]=fitness1(i);FF=[FF X0F];
end

[MAPE,FF]=DAGM(0.1,X0);
for i=0.2:0.1:1
	[MAPE,X0F]=DAGM(i,X0);FF=[FF X0F];
end

[MAPE,FF]=CFEGM(0.1,X0,3);
for i=0.2:0.1:1
[MAPE,X0F]=CFEGM(i,X0,3);FF=[FF X0F];
end