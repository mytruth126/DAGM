function D=Cumulation(Cumulative_method,n,r)
    switch Cumulative_method
        case 'CF'
            D=CF(n,r);
        case 'F'
            D=F(n,r);    
        case 'A'
            D=A(n,r);  
    end
end

function D=CF(n,r)
    D=zeros(n,n);
    for i=1:n
        for j=1:i
            D(i,j)=1./(j^(ceil(r)-r)).*gamma(i-j+ceil(r)-1+1)/(gamma(i-j+1)*gamma(ceil(r)-1+1));
        end
    end
end

function D=F(n,r)
    D=zeros(n,n);
    for i=1:n
        for j=1:i
            D(i,j)=gamma(i-j+r-1+1)/(gamma(i-j+1)*gamma(r-1+1));
            if isnan(D(i,j))
                D(i,j)=1;
            end
        end        
    end
end

function D=A(n,r)
        D=zeros(n,n);
    for i=1:n
        D(i,i)=1;
    end
    for i=2:n
        D(i,i-1)=r;
    end
end