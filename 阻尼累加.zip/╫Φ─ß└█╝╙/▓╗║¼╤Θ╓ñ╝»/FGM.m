function [MAPE,X0F]=FGM(r,X0)
%X0Ϊԭʼ����
%��ȡ����
n=numel(X0);
m=3;
%�ۼ�ϵ�����ۼ�
r;
if r==0
    Xr=X0;
else
    for k=1:n
        tmp=0;
        for i=1:k
            cc2(k,i)=gamma(r+k-i)/(gamma(k-i+1)*gamma(r));
            tmp=tmp+cc2(k,i)*X0(i);
        end
        Xr(k)=tmp;
    end
end
%����Z
for i=2:n;
    Zr(i-1)=(Xr(i)+Xr(i-1))/2;
end
Xr_1(1)=X0(1);
%����X
for k=2:n;
    Xr_1(k)=Xr(k)-Xr(k-1);
end
%�ۼ�ϵ��
for k=1:n+m;
    for i=0:k-1;
        if k-i>=1
            cc1(k,i+1)=(-1)^i*gamma(r+1)/(gamma(i+1)*gamma(r-i+1));
        else
            cc1(k,i+1)=0;
        end;
    end;
end;
%��С����
B=ones(n-1,2);
Y=ones(n-1,1);
for i=1:n-1;
    Y(i,1)=Xr_1(i+1);
    B(i,1)=-Zr(i);
end;
E=inv(B'*B)*B'*Y;
%����ϵ��
a=E(1);
b=E(2);
XrF(1)=X0(1);
%���
for k=2:n+m;
    XrF(k)=(X0(1)-b/a)*exp(-a*(k-1))+b/a;
end

%��ϻ�ԭ
if r==0
    X0F=XrF;
else
    for k=1:n+m;
        tmp=0;
        for i=1:k;
            tmp=tmp+XrF(k+1-i)*cc1(k,i);
        end;
        X0F(k)=tmp;
    end;
end;
for k=2:n;
   e(k)=abs(X0F(k)-X0(k))/X0(k);
end
MAPE=mean(e(2:n));
X0F=X0F';
end
