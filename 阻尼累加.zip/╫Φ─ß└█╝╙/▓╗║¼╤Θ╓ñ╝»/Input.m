function [ X0 ] = Input(  )
%X0Ϊԭʼ����
X0=[3.3
5.6
7.9
10.3
14.5
18.1
];


end

