function MAPE2=mape(Y,Y0)
if numel(Y)==numel(Y0)
    for i=1:numel(Y)
    e(i)=abs((Y0(i)-Y(i))/Y(i));
    end
    MAPE2=mean(e);
end
end