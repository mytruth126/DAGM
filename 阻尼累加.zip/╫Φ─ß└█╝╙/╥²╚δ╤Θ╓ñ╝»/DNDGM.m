function [MAPE,X0F] = DNDGM( r,X0,nv )
m=6;
n=numel(X0)-nv;
%�ۼ�ϵ�����ۼ�
if size(X0,1)==1
    X0=X0';
end
for i=1:n+m+nv
    for j=1:i
        D(i,j)=1/(r^(j-1));
    end
end
%����Xr����
Xr=D(1:n,1:n)*X0(1:n,:);
for i=1:n-1
    B(i,1)=Xr(i);
    B(i,2)=i;
    B(i,3)=1;
    Y(i,1)=Xr(i+1);
end
P=(B'*B)\B'*Y;
a=P(1);
b=P(2);
c=P(3);
XrF(1,1)=Xr(1);
for i=2:n+m+nv
    XrF(i,1)=a*XrF(i-1)+b*(i-1)+c;
end
%��ϻ�ԭ
X0F=D\XrF;
for k=1:nv
   e(k)=abs(X0F(n+k)-X0(n+k))/X0(n+k);
end
MAPE=mean(e);
end
